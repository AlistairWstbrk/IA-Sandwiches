Version 1.1
Thank you so much for downloading the Sandwiches Items Adder addon, this is my first one so please make sure you leave a review.

(Make sure you read this entire thing so you understand how to download this Items Adder only addon)

HOW TO INSTALL:
You must have ItemsAdder in order to use this
- Run server
- Put folder ItemsAdder in /plugins folder!
- Use command /iareload
- use command /iazip

If you have any issues or find any bugs please contact me on Discord, Alistair#6969